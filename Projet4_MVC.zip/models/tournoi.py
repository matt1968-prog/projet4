def __init__(self, nom_tournoi, lieu_tournoi, date_tournoi, joueurs, nombre_tours=4, type_tournoi="Rapide", description=""):
		self.nom_tournoi=nom_tournoi
		self.lieu_tournoi=lieu_tournoi
		self.date_tournoi=date_tournoi
		self.nombre_tours=nombre_tours
		self.type_tournoi=type_tournoi
		self.description=description
		self.joueurs=joueurs