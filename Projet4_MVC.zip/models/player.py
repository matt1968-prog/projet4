class Joueur:
    def __init__(self, name, f_name, dob, rating, sex="H", score=0):
        self.name=name
        self.f_name=f_name
        self.dob = dob
        self.sex=sex
        self.rating=rating
        self.score=score
        serialized_player = {'name': self.name, 'first name': self.f_name, 'dob' : self.dob,
        'rating' :self.rating, 'sex' : self.sex, 'score' : self.score}
        print(serialized_player)

        def __repr__(self):
            return str(self)
            
        def __str__(self):
            return f"Joueur({self.name}, {self.f_name}, {self.rating})"
            
    #Résultats des matchs et modification des scrores et classements#-> Controler
    
    def resultats_tour(): #saisie des résultats dans la vue
        for i in range(0,3):
            print(joueurs[i].name +" vs "+ joueurs[i+3].name) 
            resultat=int(input("Résultat : "))
            if resultat==1:
                joueurs[i].score+=1
            elif resultat==2:
                joueurs[i+3].score+=1
            elif resultat==0:
                joueurs[i].score+=0.5
                joueurs[i+3].score+=0.5
            else:
                print("Donnée non valide")    
        #print(str(joueurs[i].score) +" " +str(joueurs[i+3].score))# -> vue pour l'affichage, controler pour modif des scores
        
    def nouveau_classement():    
        for j in range(0,5):# utiliser sort -> dans Views
            for i in range(0,5):
                joueur=joueurs[i].score
                if joueurs[i+1].score>joueur:
                    joueurs[i], joueurs[i+1]=joueurs[i+1], joueurs[i]
                
        print("\nClassement après le 1er match : \n")        
        for i in joueurs:
            print(i.nom, i.prenom, i.score)

    def tour_suivant():
            pass

    def afficher_joueur(self):
        print(self.nom + "\n" +self.prenom+ "\n"+self.sexe+"\n"+self.rating)