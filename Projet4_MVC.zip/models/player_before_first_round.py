class JoueursPremierTour:
    def __init__(self, name, f_name, dob, rating, sex="H", score=0):
        self.name=name
        self.f_name=f_name
        self.dob = dob
        self.sex=sex
        self.rating=rating
        self.score=score
        serialized_player = {'nom': self.name, 'prénom': self.f_name, 'date de naissance' : self.dob,
        'rating' :self.rating, 'sexe' : self.sex, 'score' : self.score}
        print(serialized_player) #test

        def __repr__(self):
            return str(self)
            
        def __str__(self):
            return f"Joueur({self.name}, {self.f_name}, {self.rating})"

    def afficher_joueur(self):
        print(self.nom + "\n" +self.prenom+ "\n"+self.sexe+"\n"+self.rating)