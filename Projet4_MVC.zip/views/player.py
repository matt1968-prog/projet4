class Joueur:
    def __init__(self, nom : str, prenom : str, date_naissance, sexe, rating, score=0):
	self.nom=nom
		self.prenom=prenom
		self.date_naissance = date_naissance
		self.sexe=sexe
		self.rating=rating
		self.score=score
    
    def __repr__(self):
        return str(self)

    def __str__(self):
        return f"Joueur({self.nom})", "Joueur({self.prenom})", "Joueur({self.date_naissance})", "Joueur({self.rating})" 

	"""def __repr__(self):
		return str(self)"""

	def afficher_joueur(self):
	   	
	   	print(self.nom + "\n" +self.prenom+ "\n"+self.sexe+"\n"+self.rating)
	   			

