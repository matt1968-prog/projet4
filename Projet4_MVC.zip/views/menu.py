class Affichage_Menu:
    def __init__(self):
        menu=['1. Nouveau tournoi et saisie des joueurs', '2. Affichage des matchs','3. Saisie des resultats','4. Match du tour suivant', '5. Afficher classement', '6. Quitter']
        for i in menu:
            print(i)
